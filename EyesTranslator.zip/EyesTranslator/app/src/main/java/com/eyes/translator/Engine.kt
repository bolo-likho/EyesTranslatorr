package com.eyes.translator

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

/** English -> Hindi, poora phone par (offline) chalta hai. Pehli baar model download hota hai. */
object Engine {
    val translator: Translator by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.HINDI)
                .build()
        )
    }
    val identifier by lazy { LanguageIdentification.getClient() }
    val conditions: DownloadConditions = DownloadConditions.Builder().build()
}
