package com.eyes.translator

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("eyes", Context.MODE_PRIVATE)

    /** true = screen ke top-center, false = bottom-center */
    fun atTop(c: Context) = sp(c).getBoolean("top", true)
    fun setTop(c: Context, v: Boolean) = sp(c).edit().putBoolean("top", v).apply()

    /** Hindi text kitne second tak dikhe */
    fun hideSecs(c: Context) = sp(c).getInt("hide", 8)

    /** Optional: Claude API key (Hinglish ko bhi achhe se Hindi banane ke liye) */
    fun apiKey(c: Context) = sp(c).getString("apikey", "") ?: ""
    fun setApiKey(c: Context, k: String) = sp(c).edit().putString("apikey", k.trim()).apply()
}
