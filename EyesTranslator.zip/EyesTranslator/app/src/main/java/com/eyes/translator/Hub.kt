package com.eyes.translator

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.widget.Toast
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Notification aur chat-screen, dono yahin se translate hote hain aur ek hi overlay (aankhein) dikhate hain. */
object Hub {
    var overlay: OverlayController? = null

    /** Default OFF. Aankhon par tap karne se ON/OFF hota hai. OFF mein kuch bhi padha/translate nahi hota. */
    @Volatile var enabled = false
    private var owner: Context? = null
    private var lastText = ""
    private var lastTime = 0L
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    fun ensure(ctx: Context) {
        if (overlay?.isShowing == true) return
        overlay?.hide()
        val o = OverlayController(ctx, ctx is AccessibilityService)
        o.show()
        overlay = o; owner = ctx
    }

    fun useAccessibility(s: AccessibilityService) {
        overlay?.hide()
        val o = OverlayController(s, true)
        o.show()
        overlay = o; owner = s
    }

    fun release(ctx: Context) {
        if (owner === ctx) { overlay?.hide(); overlay = null; owner = null }
    }

    fun rebuild() { overlay?.rebuild() }

    fun toggle(ctx: Context) {
        enabled = !enabled
        overlay?.setActive(enabled)
        Toast.makeText(
            ctx.applicationContext,
            if (enabled) "Eyes ON ✅ live translate chalu" else "Eyes OFF ⏸ band",
            Toast.LENGTH_SHORT
        ).show()
        if (enabled) EyesAccessibility.instance?.baselineNow()
    }

    private fun isHindi(t: String): Boolean {
        val letters = t.count { it.isLetter() }
        if (letters == 0) return true
        val dev = t.count { it in '\u0900'..'\u097F' }
        return dev * 2 > letters
    }

    fun translateAndShow(ctx: Context, raw: String, force: Boolean = false) {
        if (!enabled && !force) return
        val msg = raw.trim()
        if (msg.isEmpty() || isHindi(msg)) return
        val now = System.currentTimeMillis()
        if (msg == lastText && now - lastTime < 3000) return
        lastText = msg; lastTime = now

        ensure(ctx)
        val ov = overlay ?: return
        ov.startLooking()
        val key = Prefs.apiKey(ctx)
        if (key.isNotBlank()) {
            io.execute {
                val r = try { callClaude(key, msg) } catch (e: Exception) { null }
                main.post {
                    if (r.isNullOrBlank()) mlkit(msg, ov) else ov.showTranslation(r)
                }
            }
        } else mlkit(msg, ov)
    }

    private fun mlkit(msg: String, ov: OverlayController) {
        Engine.identifier.identifyLanguage(msg)
            .addOnSuccessListener { lang ->
                if (lang != "en") { ov.stopLooking(); return@addOnSuccessListener }
                Engine.translator.downloadModelIfNeeded(Engine.conditions)
                    .addOnSuccessListener {
                        Engine.translator.translate(msg)
                            .addOnSuccessListener { ov.showTranslation(it) }
                            .addOnFailureListener { ov.stopLooking() }
                    }
                    .addOnFailureListener {
                        ov.showTranslation("Hindi model download nahi hua. Internet on karke app kholo.")
                    }
            }
            .addOnFailureListener { ov.stopLooking() }
    }

    private fun callClaude(key: String, msg: String): String? {
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 8000
        c.readTimeout = 15000
        c.doOutput = true
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        val prompt = "Translate this chat message into natural, simple Hindi written in Devanagari script. " +
                "The message may be English or Hinglish (Hindi typed in English letters), with typos or slang. " +
                "Keep the meaning and tone. Reply with ONLY the Hindi translation.\n\nMessage: $msg"
        val body = JSONObject()
            .put("model", "claude-haiku-5-5")
            .put("max_tokens", 300)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode != 200) return null
        val txt = c.inputStream.bufferedReader().readText()
        return JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text").trim()
    }
}
