package com.eyes.translator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/**
 * Screen-OCR mode (Accessibility ke bina): sirf ON hone par screen ko dekhta hai,
 * ON/OFF aankhon ke TAP se. OFF karte hi service band ho jati hai.
 */
class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CH = "eyes_capture"
        private const val SCALE = 0.7f

        @Volatile var running = false

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, CaptureService::class.java)) }
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var bg: Handler? = null
    private val main = Handler(Looper.getMainLooper())
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val differ = MessageDiffer()
    private var lastSig: IntArray? = null
    private var started = false

    private val timeTail = Regex("\\s*\\d{1,2}[:.]\\d{2}\\s*([AaPp]\\.?[Mm]\\.?)?\\W*$")
    private val timeOnly = Regex("^\\d{1,2}[:.]\\d{2}(\\s?[AaPp]\\.?[Mm]\\.?)?$")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (started) return START_NOT_STICKY
        goForeground()
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try { start(code, data) } catch (e: Exception) { stopSelf() }
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "Eyes Translator", NotificationManager.IMPORTANCE_LOW))
        }
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Eyes ON")
            .setContentText("Screen ke messages Hindi mein dikha rahi hu. Band karne ke liye aankhon par TAP karo.")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun start(code: Int, data: Intent) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        if (p == null) { stopSelf(); return }
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        val sw = (dm.widthPixels * SCALE).toInt()
        val sh = (dm.heightPixels * SCALE).toInt()

        val t = HandlerThread("eyes-ocr").also { it.start() }
        thread = t
        val handler = Handler(t.looper)
        bg = handler
        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        reader = r
        display = p.createVirtualDisplay(
            "eyes", sw, sh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
        )
        running = true
        started = true
        main.post { Hub.onCaptureStarted(applicationContext) }
        handler.post(loop)
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            try { tick() } catch (_: Throwable) {}
            bg?.postDelayed(this, 500)
        }
    }

    private fun tick() {
        val img = reader?.acquireLatestImage() ?: return
        val bmp: Bitmap = try {
            val plane = img.planes[0]
            val rowW = plane.rowStride / plane.pixelStride
            val full = Bitmap.createBitmap(rowW, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            if (rowW != img.width) Bitmap.createBitmap(full, 0, 0, img.width, img.height) else full
        } finally {
            img.close()
        }
        if (!changed(bmp)) return
        val res = Tasks.await(recognizer.process(InputImage.fromBitmap(bmp, 0)))
        val items = extract(res, bmp.width, bmp.height)
        val fresh = differ.fresh(items)
        if (fresh.isNotEmpty() && Hub.enabled) {
            val text = fresh.joinToString("\n")
            main.post { Hub.translateAndShow(applicationContext, text) }
        }
    }

    /** Screen badli hi nahi to OCR chalane ki zaroorat nahi (battery bachti hai) */
    private fun changed(bmp: Bitmap): Boolean {
        val gx = 24
        val gy = 48
        val sig = IntArray(gx * gy)
        for (j in 0 until gy) for (i in 0 until gx) {
            val c = bmp.getPixel(i * bmp.width / gx + bmp.width / (2 * gx), j * bmp.height / gy + bmp.height / (2 * gy))
            sig[j * gx + i] = (Color.red(c) + Color.green(c) + Color.blue(c)) / 3
        }
        val old = lastSig
        lastSig = sig
        if (old == null) return true
        var diff = 0
        for (k in sig.indices) if (Math.abs(sig[k] - old[k]) > 20) diff++
        return diff >= 3
    }

    private fun extract(res: Text, w: Int, h: Int): List<MessageDiffer.Item> {
        val occ = Hub.overlay?.occupied()?.map {
            Rect((it.left * SCALE).toInt(), (it.top * SCALE).toInt(), (it.right * SCALE).toInt(), (it.bottom * SCALE).toInt())
        } ?: emptyList()
        val out = ArrayList<MessageDiffer.Item>()
        for (b in res.textBlocks) for (l in b.lines) {
            val r = l.boundingBox ?: continue
            if (r.left > w * 0.19f) continue                      // samne wale ke messages left se shuru hote hain
            if (r.top < h * 0.12f || r.bottom > h * 0.90f) continue // header / input box chhod do
            if (occ.any { Rect.intersects(it, r) }) continue        // apni aankhon/text ko mat padho
            val t = l.text.trim().replace(timeTail, "").trim()
            if (t.length < 2 || t.count { it.isLetter() } < 2 || timeOnly.matches(t)) continue
            val key = MessageDiffer.norm(t)
            if (key.length < 2) continue
            out.add(MessageDiffer.Item(key, t, r.top))
        }
        out.sortBy { it.top }
        return out
    }

    override fun onDestroy() {
        running = false
        bg?.removeCallbacksAndMessages(null)
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        thread?.quitSafely()
        try { recognizer.close() } catch (_: Exception) {}
        Hub.onCaptureStopped()
        super.onDestroy()
    }
}
