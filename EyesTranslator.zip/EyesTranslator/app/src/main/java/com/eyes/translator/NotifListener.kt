package com.eyes.translator

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Chat band ho (ya app background mein ho) tab notification se translate karta hai. */
class NotifListener : NotificationListenerService() {

    private val messageApps = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger",
        "com.google.android.apps.messaging", "com.samsung.android.messaging",
        "com.facebook.orca", "com.instagram.android", "com.microsoft.teams",
        "com.slack", "com.google.android.gm", "com.truecaller"
    )

    override fun onListenerConnected() { Hub.ensure(this) }

    override fun onListenerDisconnected() { Hub.release(this) }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.category != Notification.CATEGORY_MESSAGE && sbn.packageName !in messageApps) return
        val ex = n.extras
        val msg = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: return
        Hub.translateAndShow(this, msg)
    }
}
