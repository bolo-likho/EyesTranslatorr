package com.eyes.translator

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Chat band ho tab bhi: kisi bhi messaging app ki notification se translate karta hai (sirf ON hone par). */
class NotifListener : NotificationListenerService() {

    private val messageApps = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger", "org.telegram.plus",
        "com.google.android.apps.messaging", "com.samsung.android.messaging",
        "com.facebook.orca", "com.facebook.mlite", "com.instagram.android", "com.snapchat.android",
        "org.thoughtcrime.securesms", "com.viber.voip", "jp.naver.line.android", "com.discord",
        "com.microsoft.teams", "com.slack", "com.google.android.gm", "com.truecaller",
        "com.linkedin.android", "com.twitter.android", "in.mohalla.sharechat", "com.imo.android.imoim"
    )

    private val skipCategories = setOf(
        Notification.CATEGORY_SERVICE, Notification.CATEGORY_STATUS, Notification.CATEGORY_PROGRESS,
        Notification.CATEGORY_CALL, Notification.CATEGORY_TRANSPORT, Notification.CATEGORY_SYSTEM
    )

    override fun onListenerConnected() { Hub.ensure(this) }

    override fun onListenerDisconnected() { Hub.release(this) }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Hub.enabled) return
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        // "Checking for new messages" jaisi system notifications translate nahi karni
        if (n.flags and (Notification.FLAG_ONGOING_EVENT or Notification.FLAG_FOREGROUND_SERVICE) != 0) return
        if (n.category in skipCategories) return
        val ex = n.extras
        val isMessage = n.category == Notification.CATEGORY_MESSAGE ||
                ex.getString(Notification.EXTRA_TEMPLATE)?.contains("MessagingStyle") == true ||
                sbn.packageName in messageApps
        if (!isMessage) return
        val msg = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: return
        val low = msg.lowercase()
        if ("checking for new messages" in low || Regex("^\\d+ (new )?messages?.*").matches(low)) return
        Hub.translateAndShow(this, msg)
    }
}
