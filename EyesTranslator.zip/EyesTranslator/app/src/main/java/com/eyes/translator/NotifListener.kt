package com.eyes.translator

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Chat band ho (ya app background mein ho) tab notification se translate karta hai. */
class NotifListener : NotificationListenerService() {

    private val messageApps = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger",
        "com.google.android.apps.messaging", "com.samsung.android.messaging",
        "com.facebook.orca", "com.instagram.android", "com.microsoft.teams",
        "com.slack", "com.google.android.gm", "com.truecaller"
    )

    override fun onListenerConnected() { Hub.ensure(this) }

    override fun onListenerDisconnected() { Hub.release(this) }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        // WhatsApp ki system notifications ("Checking for new messages" jaisi) translate nahi karni
        if (n.flags and (Notification.FLAG_ONGOING_EVENT or Notification.FLAG_FOREGROUND_SERVICE) != 0) return
        if (n.category in setOf(
                Notification.CATEGORY_SERVICE, Notification.CATEGORY_STATUS, Notification.CATEGORY_PROGRESS,
                Notification.CATEGORY_CALL, Notification.CATEGORY_TRANSPORT, Notification.CATEGORY_SYSTEM
            )
        ) return
        if (n.category != Notification.CATEGORY_MESSAGE && sbn.packageName !in messageApps) return
        val ex = n.extras
        val msg = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: return
        val low = msg.lowercase()
        if ("checking for new messages" in low || Regex("^\\d+ (new )?messages?.*").matches(low)) return
        Hub.translateAndShow(this, msg)
    }
}
