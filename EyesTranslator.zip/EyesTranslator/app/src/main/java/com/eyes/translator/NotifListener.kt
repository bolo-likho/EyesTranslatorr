package com.eyes.translator

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {

    private var overlay: OverlayController? = null
    private var lastText = ""
    private var lastTime = 0L

    private val messageApps = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger",
        "com.google.android.apps.messaging", "com.samsung.android.messaging",
        "com.facebook.orca", "com.instagram.android", "com.microsoft.teams",
        "com.slack", "com.google.android.gm", "com.truecaller"
    )

    override fun onListenerConnected() {
        instance = this
        overlay = OverlayController(this).also { it.show() }
    }

    override fun onListenerDisconnected() {
        overlay?.hide(); overlay = null
        if (instance === this) instance = null
    }

    override fun onDestroy() {
        overlay?.hide(); overlay = null
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.category != Notification.CATEGORY_MESSAGE && sbn.packageName !in messageApps) return
        val ex = n.extras
        val msg = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: return
        translateAndShow(msg)
    }

    fun translateAndShow(raw: String) {
        val msg = raw.trim()
        if (msg.isEmpty()) return
        val now = System.currentTimeMillis()
        if (msg == lastText && now - lastTime < 3000) return
        lastText = msg; lastTime = now

        val ov = overlay ?: return
        ov.startLooking()
        Engine.identifier.identifyLanguage(msg)
            .addOnSuccessListener { lang ->
                if (lang != "en") { ov.stopLooking(); return@addOnSuccessListener }
                Engine.translator.downloadModelIfNeeded(Engine.conditions)
                    .addOnSuccessListener {
                        Engine.translator.translate(msg)
                            .addOnSuccessListener { hindi -> ov.showTranslation(hindi) }
                            .addOnFailureListener { ov.stopLooking() }
                    }
                    .addOnFailureListener {
                        ov.showTranslation("Hindi model download nahi hua. Internet on karke app kholo.")
                    }
            }
            .addOnFailureListener { ov.stopLooking() }
    }

    fun rebuildOverlay() { overlay?.rebuild() }

    companion object {
        @Volatile var instance: NotifListener? = null
    }
}
