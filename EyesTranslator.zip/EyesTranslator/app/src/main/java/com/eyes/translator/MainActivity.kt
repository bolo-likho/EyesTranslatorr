package com.eyes.translator

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var posBtn: Button
    private lateinit var keyBox: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        col.addView(ImageView(this).apply {
            setImageResource(R.drawable.eyes)
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(dp(160), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(12)
            }
        })
        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, dp(12)) }
        col.addView(status)

        col.addView(button("1) Accessibility ON karo (khuli chat live translate ke liye)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("2) Notification access do (chat band ho tab ke liye)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(button("3) Overlay permission do (sirf notification wale mode ke liye)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(button("4) Hindi model download karo (ek baar, internet chahiye)") {
            Toast.makeText(this, "Download shuru...", Toast.LENGTH_SHORT).show()
            Engine.translator.downloadModelIfNeeded(Engine.conditions)
                .addOnSuccessListener { Toast.makeText(this, "Hindi model ready ✅", Toast.LENGTH_LONG).show() }
                .addOnFailureListener { Toast.makeText(this, "Download fail: internet check karo", Toast.LENGTH_LONG).show() }
        })

        col.addView(TextView(this).apply {
            text = "\nOptional: Claude API key (Hinglish ko bhi achhe se Hindi banane ke liye; internet aur thoda kharcha lagta hai)"
        })
        keyBox = EditText(this).apply {
            hint = "sk-ant-..."
            setSingleLine()
            setText(Prefs.apiKey(this@MainActivity))
        }
        col.addView(keyBox)
        col.addView(button("API key save karo") {
            Prefs.setApiKey(this, keyBox.text.toString())
            Toast.makeText(this, "Save ho gayi", Toast.LENGTH_SHORT).show()
        })

        posBtn = button("") {
            Prefs.setTop(this, !Prefs.atTop(this))
            Hub.rebuild()
            refresh()
        }
        col.addView(posBtn)
        col.addView(button("Test karo") {
            Hub.translateAndShow(applicationContext, "Hello, how are you? Please call me when you are free.")
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val acc = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .contains(packageName)
        val notif = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        val overlay = Settings.canDrawOverlays(this)
        status.text = (if (acc) "✅" else "❌") + " Accessibility (live chat)\n" +
                (if (notif) "✅" else "❌") + " Notification access\n" +
                (if (overlay) "✅" else "❌") + " Overlay permission"
        posBtn.text = "Aankhein abhi: " + (if (Prefs.atTop(this)) "TOP" else "BOTTOM") + " (badalne ke liye dabao)"
    }
}
