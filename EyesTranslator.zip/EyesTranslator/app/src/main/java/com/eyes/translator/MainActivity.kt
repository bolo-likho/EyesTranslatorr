package com.eyes.translator

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var posBtn: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        col.addView(ImageView(this).apply {
            setImageResource(R.drawable.eyes)
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(dp(160), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(12)
            }
        })
        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, dp(12)) }
        col.addView(status)

        col.addView(button("1) Notification access do") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(button("2) Overlay (display over other apps) permission do") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(button("3) Hindi model download karo (ek baar, internet chahiye)") {
            Toast.makeText(this, "Download shuru...", Toast.LENGTH_SHORT).show()
            Engine.translator.downloadModelIfNeeded(Engine.conditions)
                .addOnSuccessListener { Toast.makeText(this, "Hindi model ready ✅", Toast.LENGTH_LONG).show() }
                .addOnFailureListener { Toast.makeText(this, "Download fail: internet check karo", Toast.LENGTH_LONG).show() }
        })
        posBtn = button("") {
            Prefs.setTop(this, !Prefs.atTop(this))
            NotifListener.instance?.rebuildOverlay()
            refresh()
        }
        col.addView(posBtn)
        col.addView(button("Test karo") {
            val l = NotifListener.instance
            if (l == null) Toast.makeText(this, "Pehle notification access aur overlay permission do", Toast.LENGTH_LONG).show()
            else l.translateAndShow("Hello, how are you? Please call me when you are free.")
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val notif = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        val overlay = Settings.canDrawOverlays(this)
        status.text = (if (notif) "✅" else "❌") + " Notification access\n" +
                (if (overlay) "✅" else "❌") + " Overlay permission"
        posBtn.text = "Aankhein abhi: " + (if (Prefs.atTop(this)) "TOP" else "BOTTOM") + " (badalne ke liye dabao)"
    }
}
