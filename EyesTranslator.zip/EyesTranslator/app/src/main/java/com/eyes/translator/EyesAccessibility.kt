package com.eyes.translator

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Kisi bhi messaging app ki khuli chat se samne wale ke naye messages padhta hai (sirf ON hone par). */
class EyesAccessibility : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val differ = MessageDiffer()
    private val scan = Runnable { scanScreen() }
    private val timeRegex = Regex("^\\d{1,2}[:.]\\d{2}(\\s?[AaPp]\\.?[Mm]\\.?)?$")

    override fun onServiceConnected() {
        instance = this
        Hub.useAccessibility(this)
    }

    /** ON karte hi: abhi jo messages screen par hain unhe purana maano */
    fun baselineNow() {
        differ.reset()
        handler.removeCallbacks(scan)
        handler.postDelayed(scan, 200)
    }

    private fun skipPkg(p: String?) = p == null || p == packageName ||
            p == "com.android.systemui" || p == "com.android.settings" ||
            p.contains("launcher") || p.contains("inputmethod") ||
            p.contains("keyboard") || p.contains("honeyboard")

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (!Hub.enabled || Hub.mode != 1) { differ.reset(); return }   // OFF: kuch nahi karna
        if (skipPkg(e.packageName?.toString())) return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) differ.reset()
        handler.removeCallbacks(scan)
        handler.postDelayed(scan, 150)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(scan)
        if (instance === this) instance = null
        Hub.release(this)
        super.onDestroy()
    }

    private fun scanScreen() {
        if (!Hub.enabled || Hub.mode != 1) return
        val root = rootInActiveWindow ?: return
        if (skipPkg(root.packageName?.toString())) return
        val dm = resources.displayMetrics
        val items = ArrayList<MessageDiffer.Item>()
        collect(root, items, dm.widthPixels, dm.heightPixels)
        items.sortBy { it.top }
        val fresh = differ.fresh(items)
        if (fresh.isNotEmpty()) Hub.translateAndShow(this, fresh.joinToString("\n"))
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<MessageDiffer.Item>, w: Int, h: Int) {
        if (n == null) return
        val t = n.text?.toString()?.trim()
        if (!t.isNullOrEmpty() && !n.isEditable && !n.isPassword && n.isVisibleToUser &&
            n.className?.toString()?.contains("TextView") == true &&
            t.length > 1 && t.count { it.isLetter() } >= 2 && !timeRegex.matches(t)
        ) {
            val r = Rect()
            n.getBoundsInScreen(r)
            // samne wale ke messages left side se shuru hote hain; header/input box chhod do
            if (r.left < w * 0.17 && r.top > h * 0.12 && r.bottom < h * 0.88) {
                val key = MessageDiffer.norm(t)
                if (key.length >= 2) out.add(MessageDiffer.Item(key, t, r.top))
            }
        }
        for (i in 0 until n.childCount) collect(n.getChild(i), out, w, h)
    }

    companion object {
        @Volatile var instance: EyesAccessibility? = null
    }
}
