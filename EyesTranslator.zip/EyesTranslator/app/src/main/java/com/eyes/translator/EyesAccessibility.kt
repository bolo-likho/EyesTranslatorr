package com.eyes.translator

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Chat khuli ho tab bhi: screen par dikh rahe samne wale (left side wale) naye messages padhta hai
 * aur Hub ke zariye Hindi mein dikhata hai.
 */
class EyesAccessibility : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var prev: Map<String, Int>? = null   // null = naya screen/scroll: pehle baseline lo, translate mat karo
    private val scan = Runnable { scanScreen() }
    private val timeRegex = Regex("^\\d{1,2}[:.]\\d{2}(\\s?[AaPp]\\.?[Mm]\\.?)?$")

    override fun onServiceConnected() { Hub.useAccessibility(this) }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> prev = null
        }
        handler.removeCallbacks(scan)
        handler.postDelayed(scan, 350)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(scan)
        Hub.release(this)
        super.onDestroy()
    }

    private fun scanScreen() {
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() == packageName) return
        val dm = resources.displayMetrics
        val items = ArrayList<Pair<Int, String>>()
        collect(root, items, dm.widthPixels, dm.heightPixels)
        items.sortBy { it.first }

        val cur = HashMap<String, Int>()
        for ((_, t) in items) cur[t] = (cur[t] ?: 0) + 1
        val old = prev
        prev = cur
        if (old == null) return

        val fresh = ArrayList<String>()
        val used = HashMap<String, Int>()
        for ((_, t) in items) {
            val k = (used[t] ?: 0) + 1
            used[t] = k
            if (k > (old[t] ?: 0)) fresh.add(t)
        }
        if (fresh.isEmpty()) return
        Hub.translateAndShow(this, fresh.takeLast(3).joinToString("\n"))
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<Pair<Int, String>>, w: Int, h: Int) {
        if (n == null) return
        val t = n.text?.toString()?.trim()
        if (!t.isNullOrEmpty() && !n.isEditable && n.isVisibleToUser &&
            n.className?.toString()?.contains("TextView") == true &&
            t.length > 1 && t.any { it.isLetter() } && !timeRegex.matches(t)
        ) {
            val r = Rect()
            n.getBoundsInScreen(r)
            // samne wale ke messages left side se shuru hote hain; header/input box chhod do
            if (r.left < w * 0.17 && r.top > h * 0.12 && r.bottom < h * 0.88) out.add(r.top to t)
        }
        for (i in 0 until n.childCount) collect(n.getChild(i), out, w, h)
    }
}
