package com.eyes.translator

/**
 * Screen ke messages ki pichhli 3 frames se tulna karke sirf NAYE messages nikalta hai.
 * Naya = jo pehle se dikhe messages ke NEECHE aaya ho. Isse purane messages (scroll up) ya
 * naya chat kholne par translate nahi hote.
 */
class MessageDiffer {

    class Item(val key: String, val text: String, val top: Int)

    private val history = ArrayList<List<String>>()

    fun reset() { history.clear() }

    fun fresh(items: List<Item>): List<String> {
        val keys = items.map { it.key }
        val union = HashMap<String, Int>()
        for (f in history) {
            val c = HashMap<String, Int>()
            for (k in f) c[k] = (c[k] ?: 0) + 1
            for ((k, n) in c) if (n > (union[k] ?: 0)) union[k] = n
        }
        val pool = ArrayList<String>()
        for ((k, n) in union) repeat(n) { pool.add(k) }
        val hadHistory = pool.isNotEmpty()

        history.add(keys)
        if (history.size > 3) history.removeAt(0)
        if (!hadHistory || items.isEmpty()) return emptyList()

        val matched = BooleanArray(items.size)
        var last = -1
        for (i in items.indices) {
            var idx = pool.indexOf(items[i].key)
            if (idx < 0) idx = pool.indexOfFirst { similar(it, items[i].key) }
            if (idx >= 0) { pool.removeAt(idx); matched[i] = true; last = i }
        }
        if (last < 0) return emptyList()   // poora naya screen
        return items.indices.filter { it > last && !matched[it] }.map { items[it].text }.takeLast(3)
    }

    private fun similar(a: String, b: String): Boolean {
        if (maxOf(a.length, b.length) <= 4) return a == b
        if (Math.abs(a.length - b.length) > 2) return false
        val maxD = maxOf(1, maxOf(a.length, b.length) / 5)
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return prev[b.length] <= maxD
    }

    companion object {
        private val nonAlnum = Regex("[^\\p{L}\\p{N}]")
        fun norm(t: String) = t.lowercase().replace(nonAlnum, "")
    }
}
