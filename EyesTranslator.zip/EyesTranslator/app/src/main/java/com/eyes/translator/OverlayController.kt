package com.eyes.translator

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView

/**
 * Do chhoti windows:
 *  1) Aankhein (touch leti hain: TAP = ON/OFF)
 *  2) Hindi text (touch nahi leta, neeche wali app normal chalti hai)
 */
class OverlayController(private val ctx: Context, private val accessibility: Boolean = false) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var eyeWin: FrameLayout? = null
    private var textWin: TextView? = null
    private var eyes: ImageView? = null
    private var look: ObjectAnimator? = null
    private var active = false

    val isShowing: Boolean get() = eyeWin != null

    private val hideTextRunnable = Runnable {
        textWin?.visibility = View.GONE
        stopLooking()
    }

    /** Screen par aankhon/text ki jagah (OCR inhe na padhe, isliye) */
    fun occupied(): List<Rect> {
        val out = ArrayList<Rect>()
        for (v in listOf<View?>(eyeWin, textWin)) {
            if (v != null && v.visibility == View.VISIBLE && v.width > 0) {
                val loc = IntArray(2)
                v.getLocationOnScreen(loc)
                out.add(Rect(loc[0], loc[1], loc[0] + v.width, loc[1] + v.height))
            }
        }
        return out
    }

    private fun dp(v: Float) = (v * ctx.resources.displayMetrics.density).toInt()
    private fun idleAlpha() = if (active) ACTIVE_ALPHA else OFF_ALPHA
    private fun type() = if (accessibility) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
    else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    fun show() {
        if (eyeWin != null) return
        if (!accessibility && !Settings.canDrawOverlays(ctx)) return
        val top = Prefs.atTop(ctx)
        val grav = (if (top) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL

        val eyeW = dp(EYES_WIDTH_DP)
        val eyeH = (eyeW * 179f / 480f).toInt()
        val padH = dp(14f)
        val padV = dp(12f)   // aankhein chhoti hain, isliye tap karne ki jagah transparent padding se badi rakhi hai

        val eyeView = ImageView(ctx).apply {
            setImageResource(R.drawable.eyes)
            scaleType = ImageView.ScaleType.FIT_XY
            layoutParams = FrameLayout.LayoutParams(eyeW, eyeH)
        }
        val eyeBox = FrameLayout(ctx).apply {
            setPadding(padH, padV, padH, padV)
            setBackgroundColor(Color.TRANSPARENT)
            addView(eyeView)
            setOnClickListener { Hub.toggle(ctx) }
        }
        val textView = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            maxLines = 5
            setShadowLayer(7f, 0f, 1f, Color.BLACK)
            setPadding(dp(24f), 0, dp(24f), 0)
            visibility = View.GONE
        }

        val eyeLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = grav; y = 0 }

        val textLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT, type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = grav; y = eyeH + 2 * padV }

        try {
            wm.addView(textView, textLp)
            wm.addView(eyeBox, eyeLp)
            eyeWin = eyeBox; textWin = textView; eyes = eyeView
            applyActiveLook()
        } catch (e: Exception) {
            hide()
        }
    }

    fun hide() {
        handler.removeCallbacks(hideTextRunnable)
        look?.cancel(); look = null
        eyeWin?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        textWin?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        eyeWin = null; textWin = null; eyes = null
    }

    fun rebuild() { hide(); show() }

    /** ON = rangeen aur thodi saaf; OFF = grey aur bahut dhundhli */
    fun setActive(on: Boolean) {
        active = on
        if (!on) {
            handler.removeCallbacks(hideTextRunnable)
            textWin?.visibility = View.GONE
            look?.cancel(); look = null
            eyes?.animate()?.translationX(0f)?.start()
        }
        applyActiveLook()
        if (on) { startLooking(); handler.postDelayed({ stopLooking() }, 900) }
    }

    private fun applyActiveLook() {
        val v = eyes ?: return
        if (active) v.clearColorFilter()
        else v.colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
        v.animate().alpha(idleAlpha()).setDuration(200).start()
    }

    /** Aankhein idhar-udhar dekhne lagti hain */
    fun startLooking() {
        val v = eyes ?: return
        handler.removeCallbacks(hideTextRunnable)
        look?.cancel()
        val d = dp(5f).toFloat()
        look = ObjectAnimator.ofFloat(v, View.TRANSLATION_X, 0f, -d, d, -d / 2, d / 2, 0f).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        v.animate().alpha(1f).setDuration(150).start()
    }

    fun stopLooking() {
        val v = eyes ?: return
        look?.cancel(); look = null
        v.animate().translationX(0f).alpha(idleAlpha()).setDuration(300).start()
    }

    /** Hindi text dikhao; aankhein ghoomti rehti hain, phir text hat jata hai */
    fun showTranslation(hindi: String) {
        val t = textWin ?: return
        t.text = hindi
        t.visibility = View.VISIBLE
        startLooking()
        handler.removeCallbacks(hideTextRunnable)
        handler.postDelayed(hideTextRunnable, Prefs.hideSecs(ctx) * 1000L)
    }

    companion object {
        const val EYES_WIDTH_DP = 34f   // bahut choti; badhani ho to yahan badlo
        const val ACTIVE_ALPHA = 0.85f
        const val OFF_ALPHA = 0.3f
    }
}
