package com.eyes.translator

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Screen ke upar chhoti, transparent "aankhein" + unke saath Hindi text.
 * Overlay touch nahi leta, isliye neeche wali app normal chalti rehti hai.
 */
class OverlayController(private val ctx: Context, private val accessibility: Boolean = false) {

    val isShowing: Boolean get() = container != null

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var container: LinearLayout? = null
    private var eyes: ImageView? = null
    private var text: TextView? = null
    private var look: ObjectAnimator? = null

    private val hideTextRunnable = Runnable {
        text?.visibility = View.GONE
        stopLooking()
    }

    private fun dp(v: Float) = (v * ctx.resources.displayMetrics.density).toInt()

    fun show() {
        if (container != null) return
        if (!accessibility && !Settings.canDrawOverlays(ctx)) return
        val top = Prefs.atTop(ctx)

        val eyeView = ImageView(ctx).apply {
            setImageResource(R.drawable.eyes)
            adjustViewBounds = true
            alpha = IDLE_ALPHA
            layoutParams = LinearLayout.LayoutParams(dp(EYES_WIDTH_DP), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val textView = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            maxLines = 5
            setShadowLayer(7f, 0f, 1f, Color.BLACK)
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(2f); bottomMargin = dp(2f) }
        }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24f), 0, dp(24f), 0)
            setBackgroundColor(Color.TRANSPARENT)
            if (top) { addView(eyeView); addView(textView) } else { addView(textView); addView(eyeView) }
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (accessibility) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = (if (top) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
            y = dp(4f)
        }
        try {
            wm.addView(box, lp)
            container = box; eyes = eyeView; text = textView
        } catch (e: Exception) {
            container = null
        }
    }

    fun hide() {
        handler.removeCallbacks(hideTextRunnable)
        look?.cancel(); look = null
        container?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        container = null; eyes = null; text = null
    }

    fun rebuild() { hide(); show() }

    /** Aankhein idhar-udhar dekhne lagti hain */
    fun startLooking() {
        val v = eyes ?: return
        handler.removeCallbacks(hideTextRunnable)
        look?.cancel()
        val d = dp(5f).toFloat()
        look = ObjectAnimator.ofFloat(v, View.TRANSLATION_X, 0f, -d, d, -d / 2, d / 2, 0f).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        v.animate().alpha(1f).setDuration(150).start()
    }

    fun stopLooking() {
        val v = eyes ?: return
        look?.cancel(); look = null
        v.animate().translationX(0f).alpha(IDLE_ALPHA).setDuration(300).start()
    }

    /** Hindi text dikhao; aankhein padhte hue idhar-udhar ghoomti rehti hain, phir text hat jata hai */
    fun showTranslation(hindi: String) {
        val t = text ?: return
        t.text = hindi
        t.visibility = View.VISIBLE
        startLooking()
        handler.removeCallbacks(hideTextRunnable)
        handler.postDelayed(hideTextRunnable, Prefs.hideSecs(ctx) * 1000L)
    }

    companion object {
        const val EYES_WIDTH_DP = 34f   // bahut choti; badhani ho to yahan badlo
        const val IDLE_ALPHA = 0.55f
    }
}
