EYES TRANSLATOR - English -> Hindi live (Android)

Kaise chalayein:
1. Android Studio kholo -> Open -> is EyesTranslator folder ko chuno. Gradle sync hone do.
2. Phone USB se jodo (USB debugging on) -> Run (hari triangle). Ya Build > Build APK.
3. App kholo aur 1, 2, 3 button ek-ek karke karo:
   1) Notification access ON   2) Overlay permission ON   3) Hindi model download (ek baar)
4. "Test karo" dabao. Aankhein idhar-udhar dekhengi aur Hindi text niche aayega.

Settings:
- Aankhon ka size: OverlayController.kt mein EYES_WIDTH_DP
- Text kitni der rahe: Prefs.kt mein hideSecs (default 8 sec)
- TOP / BOTTOM: app ke andar button se
