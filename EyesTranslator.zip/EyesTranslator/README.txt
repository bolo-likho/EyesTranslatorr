EYES TRANSLATOR - live chat translate (English -> Hindi), sab messaging apps ke liye

Istemal:
1. App kholo: Accessibility, Notification access, Overlay permission do. Hindi model ek baar download karo.
2. Screen par chhoti aankhein dikhengi (grey = OFF).
3. Aankhon par TAP = ON (rangeen). Dobara TAP = OFF (grey, kuch nahi padhti).
4. ON mein: Accessibility chalu ho to wahi se chat padhti hai; nahi to screen-capture (OCR) ki permission maangti hai.
